# TECH WORLD BOT'S 
<!-- Glowing Footer -->
<p align="center">
  <img src="https://files.catbox.moe/als57o.jpg" height="40" width="100%">
</p>
<div align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=HI+THIS+IS+BLACK-MD;A+MULTI+DEVICE+WHATSAPP+BOT;SCRIPTED+BY+BLACKIE+TECH;STAR+AND+FORK+OUR+REPO" alt="Typing SVG" /></a>
  </p>

<!-- Glowing Footer -->
<p align="center">
  <img src="https://files.catbox.moe/als57o.jpg" height="40" width="100%">
</p>

  [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&size=30&pause=1000&color=ff00bd&center=true&vCenter=true&width=815&height=60&lines=▭+▬+▭+▬+▭+▬+▭+▬+▭+▬+▭)](https://git.io/typing-svg)

<!-- Glowing Footer -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>
  
<p align="center">
  
[![Black Merchant](https://github.com/Blackie254.png?lenght=50width=50)](https://github.com/Blackie254)
</p>
<p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=d1fa02&center=true&vCenter=true&multiline=false&lines=TECHWORD 𝐌𝐃" alt="">
</p>
<p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator- 𝐁𝐋𝐀𝐂𝐊𝐌𝐄𝐑𝐂𝐇𝐀𝐍𝐓-blue.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/Blackie254?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/Blackie254?label=Followers&style=social"></a>
<a href="https://github.com/Blackie254/black-super-bot/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Blackie254/black-super-bot?&style=social"></a>
<a href="https://github.com/Blackie254/black-super-bot/network/members"><img title="Fork" src="https://img.shields.io/github/forks/Blackie254/black-super-bot?style=social"></a>
<a href="https://github.com/Blackie254/black-super-bot/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Blackie254/black-super-bot?label=Watching&style=social"></a>
</p>
 
<!-- Glowing Footer -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>

## ```CONTACT ME```

<p align="center">

<a href="https://api.whatsapp.com/send?phone=254751815027&text=Hello+black"><img src="https://img.shields.io/badge/Contact 𝐁𝐋𝐀𝐂𝐊𝐌𝐄𝐑𝐂𝐇𝐀𝐍𝐓 -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />


***This bot is created with the help of NodeJS and uses [Baileys](https://github.com/whiskeysockets/Baileys)***

<!-- Glowing Footer -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>

## DISCLAIMER
- Modifying the bot structure is at your own risk. We won't offer technical support in case of errors resulting!

<!-- Glowing Footer -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>

## FEATURES
This is a highly customisable simple whatsapp bot with group management features and few media commands and chatgpt courtesy of Openai.

Our AI features use random APIs to run, so sometimes they may be down.

<!-- Glowing Footer -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>

# SET-UP

## ` Fork this repo`
<p align="centre">
<a href="https://github.com/Blackie254/black-super-bot/fork"><img src="https://img.shields.io/badge/Fork%20Create-purple?style=for-the-badge&logo=github" alt="FORK RAVEN-BOT" width="160"></a>
<p/>
  
Linking/Pairing:
## ` Pair onrender`
<p align="centre">
<a href="https://blacks-pair.onrender.com"><img height= "37" title="Author" src="https://img.shields.io/badge/Session-green?style=for-the-badge&logo=render"></a>
<p/>
            
<!-- Glowing Footer -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>

###  𝗗𝗘𝗣𝗟𝗢𝗬 𝗢𝗡 𝗛𝗘𝗥𝗢𝗞𝗨:


 
 ***[![Tap to deploy on heroku](https://www.herokucdn.com/deploy/button.svg)](https://blacks-progressive-platform.vercel.app/)***
 

    

- Fill in the required variables into your hosting site for bot to work.
 </h2>

<!-- Glowing Footer -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>

  ## credits    
<!-- Glowing Footer -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p> 
  <h1 align="center">𝐂𝐑𝐄𝐃𝐈𝐓𝐒 𝐓𝐎 𝐍𝐈𝐂𝐊 𝐇𝐔𝐍𝐓𝐄𝐑 𝐅𝐎𝐑 𝐓𝐇𝐄 𝐁𝐀𝐒𝐄</h1>
  </a>
  <!-- Glowing Footer -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>




## License

[MIT License]((https://github.com/Blackie254/black-super-bot)/LICENSE)

Copyright (c) 2025 TECH WORLD BOT'S  

<!-- Glowing Footer -->
<p align="center">
  <img src="https://i.imgur.com/dBaSKWF.gif" height="40" width="100%">
</p>
